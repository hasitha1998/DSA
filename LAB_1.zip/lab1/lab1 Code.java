package lab1;

public class lab1 {

	public static void main(String[] args) {
		
		
		Stack a=new Stack(5);
		
		a.push('a');
		a.push('b');
		a.push('c');
		a.push('d');
		a.push('e');
		
		
		while(!a.isEmpty()) {
			
			char item=a.pop();
			System.out.print(item+" ");
			
			
		}
		
		
		//insertion order==a,b,c,d,e
		//order of removal=e,d,c,b,a
		
		
		checkBrackets.validPar("3+((6*2)-3)");
		
		
		
		

	}


}


class Stack {
	
	private char []stackArray;
	
	private int top;
	private int maxsize;
	
	public Stack(int s) {
		
		this.maxsize=s;
		this.top=-1;
		stackArray=new char [maxsize];
		
		
	}
	
	public void push(char x) {
	
		if(top==maxsize-1) {
			
			System.out.println("Stack is full!!");
			
		}
		
		
		else {
		stackArray[++top]=x;
		}
		
	}
	
	public char pop() {
		
		if(top==-1) {
			
			System.out.println("stack is already empty");
			
			return 'c';
			
			
		}
		
		else {
			
			return stackArray[top--];
			
		}
		
		
	}
	
	
	public char peek() {
		
		if(top==-1) {
			
			System.out.println("no top value to return!!");
			
			return 'c';
		}
		
		else {
			
			return stackArray[top];
			
		}
		
		
		
	}
	
	
	public boolean isEmpty() {
		
		
			
			return (top==-1);
				
	}
	
	
	public boolean isFull() {
		
		return (top==maxsize-1);
		
		
	}
	
}


class checkBrackets{
	

	
public static void validPar(String input){
	
	final int len=input.length();
	
	Stack n=new Stack(len);
	
	for(int i=0; i<len; i++) {
		
		if(input.charAt(i)=='(') {
			
			n.push(input.charAt(i));
			
			continue;
			
		}
		else if (input.charAt(i)==')') {
			
			if(n.isEmpty()) {
				
				System.out.println("invalid");
				return;
				
			}
			
			else {
				
				n.pop();
				
			}
				
			
		}
	}
	
	
	if(n.isEmpty()) {
		
		System.out.println("valid expression");
	}
	
	else {
		
		System.out.println("Invalid Expression");
	}
}
	
	
}







